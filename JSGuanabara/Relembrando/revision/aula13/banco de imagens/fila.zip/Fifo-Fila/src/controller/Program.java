package controller;

import model.Fila;
import model.Pilha;

public class Program {

    public static void main(String[] args) {

       
  

        Fila fila = new Fila();

        fila.status();
        fila.insereNoFim("Heitor");
        fila.insereNoFim("Bruno");
        fila.insereNoFim("Julio");
        fila.insereNoFim("Ryan");
        fila.retornarPrimeiro();
        fila.removePrimeiro();
        fila.retornarPrimeiro();
        fila.status();

       



    }

}
