package model;
//Heitor Paiva
public class Pilha {

    private int[] inteiros = new int[10];
    private int cont;

    public Pilha() {
        cont = 0;
    }

    public void empilhar(int n) {
        if( cont + 1 > inteiros.length ) {
            System.out.println("O Array está cheio !!!");
        }
        this.inteiros[cont] = n;
        cont++;
    }

    public void desempilhar() {
        if(cont < 1) {
            System.out.println("Pilha está vazia !!!");
        }
        int n = this.inteiros[cont - 1];
        cont--;
        System.out.println("Elemento removido: " + n);


    }

    public void retornaTopo() {
        int n = inteiros[cont - 1];
        System.out.println("O ultimo elemento é " + n);
    }

}