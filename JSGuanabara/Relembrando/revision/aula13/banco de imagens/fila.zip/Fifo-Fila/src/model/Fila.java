package model;
//Heitor Paiva
public class Fila {

    private No inicio;
    private No atual;
    private No novo;

   
    public Fila() {
        this.setInicio(null);
    }

    public void removePrimeiro() {
        atual = inicio;
        if(atual == null){
            System.out.println("Lista Vazia !!!");
        }
        inicio = atual.getProximo();
    }

    public void retornarPrimeiro() {
        atual = inicio;
        if(atual == null){
            System.out.println("Lista Vazia !!!");
        }
        System.out.println(atual.getNome());
    }

    public void insereNoFim(String p) {
        atual = inicio;
        if(atual == null){
            setInicio(new No(p));
        }else {
            while (atual.getProximo() != null) {
                atual = atual.getProximo();
            }
            novo = new No(p);
            atual.setProximo(novo);

        }
    }


   


    public void status() {
        atual = inicio;
        if(atual == null){
            System.out.println("Lista Vazia !!!");
        }else {
            System.out.println("-------------------------");
            System.out.print("lista: ");
            while (atual != null) {
                System.out.print(atual.getNome() + " ---> ");
                atual = atual.getProximo();
            }
            System.out.println();
            System.out.println("-------------------------");
        }
    }



    private No getInicio() {
        return inicio;
    }

    private void setInicio(No inicio) {
        this.inicio = inicio;
    }

    private No getAtual() {
        return atual;
    }

    private void setAtual(No atual) {
        this.atual = atual;
    }

    private No getNovo() {
        return novo;
    }

    private void setNovo(No novo) {
        this.novo = novo;
    }
}