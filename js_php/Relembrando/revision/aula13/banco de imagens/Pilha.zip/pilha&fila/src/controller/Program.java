package controller;

import model.Fila;
import model.Pilha;

public class Program {

    public static void main(String[] args) {

       
        Pilha pilha = new Pilha();

        pilha.empilhar(3);
        pilha.empilhar(2);
        pilha.empilhar(3);
        pilha.empilhar(4);
        pilha.empilhar(5);
        pilha.empilhar(6);
        pilha.empilhar(7);
        pilha.empilhar(8);
        pilha.empilhar(9);
        pilha.empilhar(10);
        pilha.retornaTopo();
        pilha.desempilhar();
        pilha.desempilhar();

       



    }

}
