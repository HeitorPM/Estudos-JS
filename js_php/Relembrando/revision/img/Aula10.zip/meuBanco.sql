use meubanco;
CREATE TABLE perfil (
  id_perfil int(2) unsigned NOT NULL,
  desc_perfil varchar(200), 
  nome_perfil varchar(30) NOT NULL, 
  PRIMARY KEY (id_perfil)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE admin (
	id_admin int(11) unsigned NOT NULL AUTO_INCREMENT,
    email_admin varchar(60) NOT NULL, 
	senha_admin varchar(30) NOT NULL, 
    id_perfil int(2) unsigned NOT NULL,
	PRIMARY KEY(id_admin),
    FOREIGN KEY(id_perfil) REFERENCES perfil(id_perfil)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE cliente (
	id_cliente int(11) unsigned NOT NULL AUTO_INCREMENT,
    nome_cliente varchar(20)  NOT NULL, 
    sobrenome_cliente varchar(40)  NOT NULL,
    email_cliente varchar(60) NOT NULL, 
    senha_cliente varchar(30) NOT NULL, 
    CPF_cliente varchar(11) NOT NULL, 
    nascimento_cliente date NOT NULL, 
    sexo char NOT NULL, 
    id_perfil int(2) unsigned NOT NULL,
    PRIMARY KEY(id_cliente),
    FOREIGN KEY(id_perfil) REFERENCES perfil(id_perfil)
)ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO perfil VALUES(1,"Usuário Administrador", "admin");
INSERT INTO perfil VALUES(5,"Usuário Cliente", "cliente");

INSERT INTO admin (email_admin, senha_admin, id_perfil) 
VALUES("dsilos@dsilos.com", "1234", 1); 

INSERT INTO cliente (nome_cliente, sobrenome_cliente, 
email_cliente, senha_cliente, CPF_cliente, 
nascimento_cliente, sexo,id_perfil) 
VALUES ("Bete", "Lima", "bete@bete.com",
"1234", "77777777777", 
STR_TO_DATE('27-04-2020', '%d-%m-%Y') ,"F",5);


/*
CREATE TABLE `user_login` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(60) NOT NULL,
  senha varchar(30) NOT NULL, 
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
*/
